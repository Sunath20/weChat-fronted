import { DOWNLOAD_EVENTS } from "../core/Actions";
import { downloadManager } from "../core/DownloadManager";
import { eventBus } from "../core/EventBus";



export function initDownloadListener(){


    eventBus.on(DOWNLOAD_EVENTS.START_DOWNLOAD,({roomID,messageID,fileName,mimeType}) => {
        downloadManager.addFile(roomID,messageID,fileName);
    })
}