import { apiHandler } from "../handlers/requestHandling";
import { DOWNLOAD_EVENTS } from "./Actions";
import { eventBus } from "./EventBus";


class Queue {
    constructor() {
        this.items = [];
    }

    // Add element to the end of the queue
    enqueue(element) {
        this.items.push(element);
    }

    // Remove and return the first element from the queue
    dequeue() {
        if (this.isEmpty()) {
            return "Queue is empty";
        }
        return this.items.shift();
    }

    // View the first element in the queue
    peek() {
        return this.items[0];
    }

    // Check if the queue is empty
    isEmpty() {
        return this.items.length === 0;
    }

    // Get the size of the queue
    size() {
        return this.items.length;
    }

    find(func){
        return this.items.find(func);
    }

    remove(messageID){
        const index = this.items.findIndex(e => e.messageID === messageID);
        if(index !== -1) this.items.splice(index, 1);
    }
}


export const DOWNLOADING_STATUS = {
    WAITING:"WAITING",
    DOWNLOADING:"DOWNLOADING",
    PAUSED:"PAUSED",
}


class DownloadManager {
    
    constructor(downloadLimit=5){
        this.serverBase = apiHandler.serverBase;
        this.downloads = new Queue();
        this.downloadSignals = new Map();
        this.currentDownloads = new Set();
        this.pausedDownloads = new Map();
        this.downloadLimit = downloadLimit;
        this.retryInfo = new Map();
        this.maximumRetries = 5;
    }


    addFile(roomID,messageID,fileName){
        const fileInfo = this.downloads.find(e => e.messageID == messageID)
        if(fileInfo || this.currentDownloads.has(messageID) || this.pausedDownloads.has(messageID)){return;}

        this.downloads.enqueue({roomID,messageID,fileName});
        this._processQueue();
    }

    async _downloadFile({roomID,messageID,fileName}){
                
                const url = this.serverBase + "/" + "readFile" + "/" + roomID+"/"+ this._downloadFileName(messageID,fileName)
                if(this.downloadSignals.has(messageID)){
                    return;
                }

                const controller = new AbortController();
                this.downloadSignals.set(messageID,controller);
               const response = await fetch(url,{signal:controller.signal})
               if(!response.ok){
                    this._downloadFailed({roomID,messageID,fileName});
                     return;
               };
       
               const fileSize = response.headers.get('Content-Length')
               eventBus.emit(DOWNLOAD_EVENTS.INIT_FILE_SIZE,{messageID,fileSize})
       
               const reader = response.body.getReader()
       
               let receiveLength = 0
               let anyError = false;
               let chunks = 0;
       
               try {
                       while (true){
                       const {done,value} = await reader.read()
                       
                       if(done){
                        this._downloadFinish({roomID,fileName,messageID})
                        break;
                       }
                       receiveLength += value.length;
                       chunks += 1;
                       eventBus.emit(DOWNLOAD_EVENTS.RECEIVED_A_CHUNK,{downloaded:receiveLength,fileSize,downloadedChunks:chunks,chunk:value,messageID,fileName,roomID});
                       await sleep(1)
                   }
               }catch(error){
                   
                   if(error.name === "AbortError"){
       
                   return null;
                   }
       
                   throw error;
               }

    }

    _downloadFailed({roomID,messageID,fileName}){
        let retries = this.retryInfo.get(messageID) || 0;
        retries += 1;
        this.retryInfo.set(messageID,retries)
        if(retries < this.maximumRetries){
            this._downloadFile({roomID,messageID,fileName});
        }else{
            this.currentDownloads.delete(messageID);
            this.downloadSignals.delete(messageID);
            this.retryInfo.delete(messageID);
            eventBus.emit(DOWNLOAD_EVENTS.FAILED_TO_DOWNLOAD,messageID)
        }

    }

    pauseDownload(messageID){
        if(this.currentDownloads.has(messageID)){
            this.currentDownloads.delete(messageID);
            this.downloadSignals.get(messageID).abort();
            this.downloadSignals.delete(messageID);
            this.retryInfo.delete(messageID);
            this.pausedDownloads.set(messageID,'PAUSED');
            eventBus.emit(DOWNLOAD_EVENTS.PAUSED_DOWNLOADS,messageID);
        }

        this._processQueue()
    }

    removeDownload(messageID){
          if(this.currentDownloads.has(messageID)){
            this.currentDownloads.delete(messageID);
            this.downloadSignals.get(messageID).abort();
            this.downloadSignals.delete(messageID);
            this.retryInfo.delete(messageID)
            eventBus.emit(DOWNLOAD_EVENTS.REMOVE_DOWNLOAD,messageID);
            this._processQueue()
            return;
        }

        const file = this.downloads.find(e => e.messageID === messageID)
        if(file){
            this.downloads.remove(messageID);
            this._processQueue()
        }
        }

     _downloadFinish({roomID,messageID,fileName}){
        this.currentDownloads.delete(messageID)
        this.downloadSignals.delete(messageID);
        this.retryInfo.delete(messageID)
        this._processQueue()
    }

    _downloadFileName(messageID,fileName){
        return `${messageID}-${fileName}`
    }

    _processQueue(){
        while( !this.downloads.isEmpty() && this.currentDownloads.size < this.downloadLimit){
            const {messageID,fileName,roomID} = this.downloads.dequeue();
            this.currentDownloads.add(messageID);
            this._downloadFile({roomID,messageID,fileName});
        }
    }

}


export const downloadManager = new DownloadManager()